package com.example.apppeluqueria

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
