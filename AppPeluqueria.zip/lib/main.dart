import 'package:flutter/material.dart';
import 'package:apppeluqueria/MyApp.dart';

// Punto de entrada de la aplicación Flutter
void main() => runApp(MyApp());
