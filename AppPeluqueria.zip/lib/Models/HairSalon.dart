// Definición de la clase HSalon que modela los datos del salón de belleza
class HSalon {
  final String bName;
  final String nit;
  final String address;
  final String locality;
  final String email;

  // Constructor de la clase HSalon
  HSalon({
    required this.bName,
    required this.nit,
    required this.address,
    required this.locality,
    required this.email,
  });

// Factory constructor para crear una instancia HSalon desde el JSON
  factory HSalon.fromJson(Map<String, dynamic> json) => HSalon(
        bName: json["razon_social"] ?? 'Nombre Desconocido',
        nit: json["nit"] ?? 'NIT Desconocido',
        address: json["direccion_comercial"] ?? 'Dirección Desconocida',
        locality: json["municipio_comercial"] ?? 'Localidad Desconocida',
        email: json["email_comercial"] ?? 'Email Desconocido',
      );

// Factory constructor para crear una instancia HSalon desde una lista de datos
  factory HSalon.fromList(List<dynamic> list) {
    return HSalon(
      bName: list[0]["razon_social"],
      nit: list[0]["nit"],
      address: list[0]["direccion_comercial"],
      locality: list[0]["municipio_comercial"],
      email: list[0]["email_comercial"],
    );
  }
}
