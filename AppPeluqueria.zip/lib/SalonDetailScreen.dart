import 'package:flutter/material.dart';
import 'package:apppeluqueria/Models/HairSalon.dart';

class SalonDetailsScreen extends StatelessWidget {
  final HSalon salon;

  SalonDetailsScreen(this.salon);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(''),
          backgroundColor: Color(0xffb969cd),
        ),
        body: Center(
          child: Card(
            elevation: 4,
            margin: EdgeInsets.all(14),
            child: Container(
              constraints: BoxConstraints(maxHeight: 300),
              padding: EdgeInsets.all(14),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    'Peluqueria: ${salon.bName}',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    'NIT: ${salon.nit}',
                    style: TextStyle(fontSize: 16),
                  ),
                  Text(
                    'Dirección: ${salon.address}',
                    style: TextStyle(fontSize: 16),
                  ),
                  Text(
                    'Ciudad: ${salon.locality}',
                    style: TextStyle(fontSize: 16),
                  ),
                  Text(
                    'E-mail: ${salon.email}',
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
          ),
        ));
  }
}
