import 'dart:convert';
import 'package:apppeluqueria/Models/HairSalon.dart';
import 'package:apppeluqueria/MyHomePage.dart';
import "package:http/http.dart" as http;

// Función asincrónica para obtener datos de salones desde una API
Future<List<HSalon>> fetchdate() async {
  // Realizar una solicitud HTTP GET a la URL de la API
  final response = await http
      .get(Uri.parse('https://www.datos.gov.co/resource/e27n-di57.json'));

  // Comprobar si la respuesta HTTP tiene un estado 200 (OK)
  if (response.statusCode == 200) {
    // Decodificar el cuerpo de la respuesta en una lista de objetos JSON
    final List<dynamic> jsonList = json.decode(response.body);

    // Mapear la lista de objetos JSON a una lista de instancias de HSalon
    return jsonList.map((json) => HSalon.fromJson(json)).toList();
  } else {
    // Lanzar una excepción si la solicitud falla
    throw Exception('Failed to fetch data');
  }
}
