import 'package:apppeluqueria/Models/HairSalon.dart';
import 'package:flutter/material.dart';
import 'package:apppeluqueria/MyHomePage.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:apppeluqueria/Provider/Provider.dart';

// Clase principal que define la aplicación Flutter
class MyApp extends StatefulWidget {
  // Constructor de la clase MyApp
  const MyApp({super.key});

  @override
  State<MyApp> createState() =>
      _MyAppState(); // Crea el estado de la clase MyApp
}

// Estado de la clase MyApp
class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Nombre de la aplicación
      title: 'Hair Salon Explorer',
      // Tema de la aplicación
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Monserrat',
      ),
      // A widget which will be started on application startup
      home: MyHomePage(),
    );
  }
}
