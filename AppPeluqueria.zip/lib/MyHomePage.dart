import 'package:flutter/material.dart';
import 'package:apppeluqueria/Provider/Provider.dart';
import 'package:apppeluqueria/Models/HairSalon.dart';
import 'package:apppeluqueria/SalonDetailScreen.dart';

// Página principal que muestra la lista de salones de belleza
class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  // Variable para almacenar el futuro de obtención de datos
  Future<List<HSalon>>? _hSalonFuture;

  // Controlador de scroll para el ListView
  ScrollController _scrollController = ScrollController();

  // Lista para almacenar los salones
  List<HSalon> _salons = [];

  @override
  void initState() {
    super.initState();

    // Inicializar el futuro de obtención de datos y el controlador de scroll
    _hSalonFuture = fetchdate();
    _scrollController.addListener(_scrollListener);
  }

  // Función para escuchar los eventos de scroll
  void _scrollListener() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      _loadMoreData();
    }
  }

  // Función para cargar más datos al hacer scroll
  void _loadMoreData() async {
    final newData = await fetchdate();
    setState(() {
      _salons.addAll(newData);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Image.asset(
            'assets/tijera.png'), // Imagen en el lado izquierdo del AppBar
        title: Text(
          'HAIRSALON EXPLORER', // Título del AppBar
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Color(0xffb969cd), // Color de fondo del AppBar
      ),
      body: Center(
        // Usar FutureBuilder para construir la interfaz basada en los datos futuros
        child: FutureBuilder<List<HSalon>>(
          future: _hSalonFuture, // El futuro que contiene la lista de salones
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              // Comprobar si los datos están disponibles
              _salons =
                  snapshot.data!; // Almacenar los datos en la lista de salones

              // Construir un ListView con los salones
              return ListView.builder(
                controller:
                    _scrollController, // Usar el controlador de scroll definido
                itemCount: _salons.length, // Cantidad de elementos en la lista
                itemBuilder: (context, index) {
                  final modelSalon =
                      _salons[index]; // Obtener el salón en la posición actual

                  // Usar InkWell para hacer que la tarjeta sea clicable
                  return InkWell(
                    onTap: () {
                      // Navegar a la pantalla de detalles del salón al hacer clic
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => SalonDetailsScreen(
                              modelSalon), // Pasar el salón a la siguiente pantalla
                        ),
                      );
                    },
                    child: Card(
                      elevation: 2,
                      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: ListTile(
                        title: RichText(
                          text: TextSpan(
                            style: DefaultTextStyle.of(context).style,
                            children: <TextSpan>[
                              TextSpan(
                                text: 'PELUQUERIA: ',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 18),
                              ),
                              TextSpan(
                                text: modelSalon.bName,
                                style: TextStyle(
                                    fontSize: 18 // Estilo de fuente light
                                    ),
                              ),
                            ],
                          ),
                        ),
                        subtitle: Text(
                          'NIT: ${modelSalon.nit}', // Concatena el texto "NIT:" con la variable
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            } else {
              return CircularProgressIndicator();
            }
          },
        ),
      ),
    );
  }
}
